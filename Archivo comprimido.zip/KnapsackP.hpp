//
//  KnapsackP.hpp
//  Projecto nap
//
//  Created by Enrique Rodriguez on 17/03/17.
//  Copyright © 2017 Enrique Rodriguez. All rights reserved.
//

#ifndef KnapsackP_hpp
#define KnapsackP_hpp

#include <stdio.h>
#include <iostream>
#include "Knapsack.hpp"
#include "Item.hpp"
using namespace std;

class KnapsackP // Knapsack Problelm
{
    


// private :  items , Knapsack...
// public : KnapsackP()  y Solve()
    
};

#endif /* KnapsackP_hpp */
